COMP3211 Group 89 - USABILITY RELEASE CANDIDATE
Not a final submission: real System_Demo.mp4, Presentation_Recording.mp4 and
the completed official Honour Declaration are still missing.
Final deadline in the supplied course PDF: 20 November 2026, 20:00.
Review genuine member details, contributions and AI disclosure before submission.
Open 03_Implementation/README.md to run and test. Both required coverage PDFs
are directly in that source-code root. Fresh evidence is in its evidence/ folder.
The editable PPTX is included alongside the required presentation PDF.
SHA256SUMS.txt lists every other payload file; it does not hash itself.
